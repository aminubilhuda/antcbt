<?php
$copyright = 'ANT CBT';

define("VERSI", "2.9");
define("REVISI", "1");
define("APLIKASI", "ANT CBT");
define("NAMA_DATABASE", "antcbt");
define("VERSI_DB", "2.8.1");
define("BASEPATH", "antcbt");
